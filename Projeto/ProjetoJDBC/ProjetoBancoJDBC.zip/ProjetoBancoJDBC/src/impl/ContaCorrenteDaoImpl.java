package impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.ContaCorrenteDao;
import model.ContaCorrente;
import model.util.Conexao;

public class ContaCorrenteDaoImpl implements ContaCorrenteDao {
	
    Conexao conexao;

	public ContaCorrenteDaoImpl(Conexao conexao) {
		super();
		this.conexao = conexao;
	}

	@Override
	public void salvar(ContaCorrente contaCorrente) {
		
		Connection conn = conexao.getConnection();
		
		//String sql = "INSERT INTO ContaCorrente (NUMERO,SALDO, LIMITE) " + "VALUES (?, ?, ?)";
		String sql = "INSERT INTO ContaCorrente (NUMERO,SENHA,SALDO) " + "VALUES (?,?,?)";
		
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, contaCorrente.getNumeroConta());
			ps.setString(2, contaCorrente.getSenha());
			ps.setDouble(3, contaCorrente.getSaldo());
			//ps.setDouble(3, contaCorrente.getLimite());
			ps.executeUpdate();
			System.out.println("ContaCorrente inserida com sucesso");
		} 
		catch (SQLException e) {
			System.out.println("Erro ao inserir ContaCorrente no banco" + e.getMessage());
		}
		finally {
			conexao.fecharConexao(conn);
		}
		
	}

	@Override
	public void alterar(ContaCorrente contaCorrente) {
		
		Connection conn = conexao.getConnection();
		
		String sql = "UPDATE ContaCorrente SET SALDO = ? , SENHA = ? WHERE NUMERO = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setDouble(1, contaCorrente.getSaldo());
			ps.setString(2, contaCorrente.getSenha());
			ps.setString(3, contaCorrente.getNumeroConta());
			ps.executeUpdate();
			System.out.println("ContaCorrente atualizada com sucesso");
			
		} catch (Exception e) {
			System.out.println("Erro ao atualizar a ContaCorrente no banco" + e.getMessage());
			
		}finally {
			conexao.fecharConexao(conn);
		}
	}

	@Override
	public void remover(String numero) {
		
		Connection conn = conexao.getConnection();
		
		String sql = "DELETE FROM ContaCorrente WHERE NUMERO = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, numero);
			ps.execute();
			System.out.println("ContaCorrente deletada com sucesso!");
			
		} catch (Exception e) {
			System.out.println("Erro ao deletar ContaCorrente no banco" + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}
		
	}

	@Override
	public ContaCorrente pesquisar(String numero) {
		
		Connection conn = conexao.getConnection();
		ContaCorrente contaCorrente = new ContaCorrente();
		
		String sql = "SELECT * FROM ContaCorrente WHERE NUMERO = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, numero);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				contaCorrente.setNumeroConta(rs.getString("NUMERO"));
				contaCorrente.setSaldo(rs.getDouble("SALDO"));
				contaCorrente.setSenha(rs.getString("SENHA"));;
			}
		} catch (Exception e) {
			System.out.println("Erro ao pesquisar ContaCorrente" + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}
		return contaCorrente;
	}

	@Override
	public List<ContaCorrente> ListarTodos() {
		
		Connection conn = conexao.getConnection();
		List<ContaCorrente> retorno = new ArrayList<ContaCorrente>();
		
		String sql = "SELECT * FROM ContaCorrente";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				ContaCorrente ContaCorrente = new ContaCorrente();
				ContaCorrente.setNumeroConta(rs.getString("NUMERO"));
				ContaCorrente.setSaldo(rs.getDouble("SALDO"));
				ContaCorrente.setSenha(rs.getString("SENHA"));;
				retorno.add(ContaCorrente);
			}
		} catch (Exception e) {
			System.out.println("Erro ao pesquisar ContaCorrente." + e.getMessage());
			
		} finally {
			conexao.fecharConexao(conn);
		}
		return retorno;
	}

}
