package impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.ContaPoupancaDao;
import model.ContaPoupanca;
import model.ContaPoupanca;
import model.util.Conexao;

public class ContaPoupancaDaoImpl implements ContaPoupancaDao{

    Conexao conexao;
	
	public ContaPoupancaDaoImpl(Conexao conexao) {
		super();
		this.conexao = conexao;
	}

	@Override
	public void salvar(ContaPoupanca contaPoupanca) {
Connection conn = conexao.getConnection();
		
		String sql = "INSERT INTO ContaPoupanca (NUMERO,SENHA,SALDO) " + "VALUES (?,?,?)";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, contaPoupanca.getNumeroConta());
			ps.setString(2, contaPoupanca.getSenha());
			ps.setDouble(3, contaPoupanca.getSaldo());
			ps.executeUpdate();
			System.out.println("ContaPoupanca inserida com sucesso");
		} 
		catch (SQLException e) {
			System.out.println("Erro ao inserir ContaPoupanca no banco" + e.getMessage());
		}
		finally {
			conexao.fecharConexao(conn);
		}
	}

	@Override
	public void alterar(ContaPoupanca contaPoupanca) {
Connection conn = conexao.getConnection();
		
		String sql = "UPDATE ContaPoupanca SET SALDO = ? , SENHA = ? WHERE NUMERO = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setDouble(1, contaPoupanca.getSaldo());
			ps.setString(2, contaPoupanca.getSenha());
			ps.setString(3, contaPoupanca.getNumeroConta());
			ps.executeUpdate();
			System.out.println("ContaPoupanca atualizada com sucesso");
			
		} catch (Exception e) {
			System.out.println("Erro ao atualizar a ContaPoupanca no banco" + e.getMessage());
			
		}finally {
			conexao.fecharConexao(conn);
		}
		
	}

	@Override
	public void remover(String numero) {
		
	Connection conn = conexao.getConnection();
		
		String sql = "DELETE FROM ContaPoupanca WHERE NUMERO = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, numero);
			ps.execute();
			System.out.println("ContaPoupanca deletada com sucesso!");
			
		} catch (Exception e) {
			System.out.println("Erro ao deletar ContaPoupanca no banco" + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}
	}

	@Override
	public ContaPoupanca pesquisar(String numero) {
		
		Connection conn = conexao.getConnection();
		ContaPoupanca contaPoupanca = new ContaPoupanca();
		
		String sql = "SELECT * FROM ContaPoupanca WHERE NUMERO = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, numero);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				contaPoupanca.setNumeroConta(rs.getString("NUMERO"));
				contaPoupanca.setSaldo(rs.getDouble("SALDO"));
				contaPoupanca.setSenha(rs.getString("SENHA"));;
			}
		} catch (Exception e) {
			System.out.println("Erro ao pesquisar ContaPoupanca" + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}
		return contaPoupanca;
	}

	@Override
	public List<ContaPoupanca> ListarTodos() {
		
		Connection conn = conexao.getConnection();
		List<ContaPoupanca> retorno = new ArrayList<ContaPoupanca>();
		
		String sql = "SELECT * FROM ContaPoupanca";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				ContaPoupanca contaPoupanca = new ContaPoupanca();
				contaPoupanca.setNumeroConta(rs.getString("NUMERO"));
				contaPoupanca.setSaldo(rs.getDouble("SALDO"));
				contaPoupanca.setSenha(rs.getString("SENHA"));
				retorno.add(contaPoupanca);
			}
		} catch (Exception e) {
			System.out.println("Erro ao pesquisar ContaPoupanca." + e.getMessage());
			
		} finally {
			conexao.fecharConexao(conn);
		}
		return retorno;
	}

}
