package impl;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.EnderecoDao;
import model.Endereco;
import model.util.Conexao;

public class EnderecoDaoImpl implements EnderecoDao {

	Conexao conexao;

	public EnderecoDaoImpl(Conexao conexao) {
		super();
		this.conexao = conexao;
	}

	@Override
	public Integer salvar(Endereco endereco) {

		String sql = "INSERT INTO ENDERECO(RUA, NUMERO, COMPLEMENTO, CIDADE, ESTADO)" + "VALUES(?, ?, ?, ?, ?)";

		Connection conn = conexao.getConnection();

		try {
			PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);  
			ps.setString(1, endereco.getRua());
			ps.setInt(2, endereco.getNumero());
			ps.setString(3, endereco.getComplemento());
			ps.setString(4, endereco.getCidade());
			ps.setString(5, endereco.getEstado());
			ps.executeUpdate();
			System.out.println("Endereço salvo com sucesso!");
	
			 ResultSet generatedKeys = ps.getGeneratedKeys();
			 
	            if (generatedKeys.next()) {
	                endereco.setId(generatedKeys.getInt(1));
	            }

		} catch (SQLException e) {
			System.out.println("Erro ao inserir endereço no banco" + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}
		
		return endereco.getId();

	}

	@Override
	public void alterar(Endereco endereco) {

		Connection conn = conexao.getConnection();

		String sql = "UPDATE ENDERECO SET RUA = ? , NUMERO = ?, COMPLEMENTO = ?, CIDADE = ?, ESTADO = ? WHERE ID_ENDERECO = ?";

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, endereco.getRua());
			ps.setInt(2, endereco.getNumero());
			ps.setString(3, endereco.getComplemento());
			ps.setString(4, endereco.getCidade());
			ps.setString(5, endereco.getEstado());
			ps.setInt(6, endereco.getId());
			ps.executeUpdate();
			System.out.println("Endereço atualizado com sucesso!");

		} catch (Exception e) {
			System.out.println("Erro ao atualizar o endereço no banco" + e.getMessage());

		} finally {
			conexao.fecharConexao(conn);
		}

	}

	@Override
	public void remover(int id) {

		Connection conn = conexao.getConnection();

		String sql = "DELETE FROM ENDERECO WHERE ID_ENDERECO = ?";

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.execute();
			System.out.println("Endereço deletado com sucesso!");

		} catch (SQLException e) {
			System.out.println("Erro ao deletar endereço no banco" + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}

	}

	@Override
	public Endereco pesquisar(int id) {

		Connection conn = conexao.getConnection();
		Endereco endereco = new Endereco();

		String sql = "SELECT * FROM ENDERECO WHERE ID_ENDERECO = ?";

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				endereco.setComplemento(rs.getString("COMPLEMENTO"));
				endereco.setId(rs.getInt("ID_ENDERECO"));
				endereco.setNumero(rs.getInt("NUMERO"));
				endereco.setRua(rs.getString("RUA"));
				endereco.setCidade(rs.getString("CIDADE"));
				endereco.setEstado(rs.getString("ESTADO"));
			}
		} catch (Exception e) {
			System.out.println("Erro ao pesquisar endereço " + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}
		return endereco;
	}

	@Override
	public List<Endereco> ListarTodos() {

		Connection conn = conexao.getConnection();
		List<Endereco> retorno = new ArrayList<Endereco>();

		String sql = "SELECT * FROM ENDERECO";

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Endereco endereco = new Endereco();
			
				endereco.setId(rs.getInt("ID_ENDERECO"));
				endereco.setRua(rs.getString("RUA"));
				endereco.setNumero(rs.getInt("NUMERO"));
				endereco.setComplemento(rs.getString("COMPLEMENTO"));
				endereco.setCidade(rs.getString("CIDADE"));
				endereco.setEstado(rs.getString("ESTADO"));
				retorno.add(endereco);
			}
		} catch (Exception e) {
			System.out.println("Erro ao pesquisar conta." + e.getMessage());

		} finally {
			conexao.fecharConexao(conn);
		}
		return retorno;
	}

}
