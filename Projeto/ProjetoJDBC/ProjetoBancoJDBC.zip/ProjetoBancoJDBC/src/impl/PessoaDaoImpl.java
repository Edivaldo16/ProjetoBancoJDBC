package impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.ContaCorrenteDao;
import dao.ContaPoupancaDao;
import dao.EnderecoDao;
import dao.PessoaDao;
import model.Pessoa;
import model.util.Conexao;

public class PessoaDaoImpl implements PessoaDao {

	Conexao conexao;
	EnderecoDao enderecoDAO;
	ContaCorrenteDao contaCorrenteDao;
	ContaPoupancaDao contaPoupancaDao;

	public PessoaDaoImpl(Conexao conexao) {
		super();
		this.conexao = conexao;
		enderecoDAO = new EnderecoDaoImpl(this.conexao);
		contaCorrenteDao = new ContaCorrenteDaoImpl(this.conexao);
		contaPoupancaDao = new ContaPoupancaDaoImpl(this.conexao);
	}

	@Override
	public void salvar(Pessoa pessoa) {

		Connection conn = conexao.getConnection();

		String sql = "INSERT INTO PESSOA(NOME, CPF, SEXO, IDADE, EMAIL, ID_ENDERECO, CONTA_CORRENTE, CONTA_POUPANCA)"
				+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			Integer id = this.enderecoDAO.salvar(pessoa.getEndereco());
			this.contaCorrenteDao.salvar(pessoa.getContaCorrente());
			this.contaPoupancaDao.salvar(pessoa.getContaPoupanca());

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, pessoa.getNome());
			ps.setString(2, pessoa.getCpf());
			ps.setString(3, pessoa.getSexo());
			ps.setInt(4, pessoa.getIdade());
			ps.setString(5,pessoa.getEmail());
			ps.setInt(6, id);
			ps.setString(7, pessoa.getContaCorrente().getNumeroConta());
			ps.setString(8, pessoa.getContaPoupanca().getNumeroConta());
			ps.executeUpdate();
			System.out.println("Inserido com sucesso");

		} catch (SQLException e) {
			System.out.println("Erro ao inserir no banco" + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}

	}

	@Override
	public void alterar(Pessoa pessoa) {

		Connection conn = conexao.getConnection();
		
		String sql = "UPDATE pessoa SET NOME = ?, SEXO = ?, IDADE = ?, EMAIL = ?"
				+ " ID_ENDERECO = ?, CONTA_CORRENTE = ?, CONTA_POUPANCA = ? WHERE CPF = ?";

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, pessoa.getNome());
			ps.setString(2, pessoa.getSexo());
			ps.setInt(3, pessoa.getIdade());
			ps.setString(4, pessoa.getEmail());
			ps.setInt(5, pessoa.getEndereco().getId());
			ps.setString(6, pessoa.getContaCorrente().getNumeroConta());
			ps.setString(7, pessoa.getContaPoupanca().getNumeroConta());
			ps.setString(8, pessoa.getCpf());
			ps.executeUpdate();
			System.out.println("Atualizado com sucesso");

		} catch (Exception e) {
			System.out.println("Erro ao atualizar pessoa no banco" + e.getMessage());

		} finally {
			conexao.fecharConexao(conn);
		}

	}

	@Override
	public void remover(String cpf) {

		Connection conn = conexao.getConnection();
		Pessoa p = pesquisar(cpf);

		String sql = "DELETE FROM PESSOA WHERE CPF = ?";

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, cpf);
			ps.execute();
			System.out.println("Pessoa deletada com sucesso");
			contaCorrenteDao.remover(p.getContaCorrente().getNumeroConta());
			contaPoupancaDao.remover(p.getContaPoupanca().getNumeroConta());
			enderecoDAO.remover(p.getEndereco().getId());
		} catch (Exception e) {
			System.out.println("Erro ao erro deletar pessoa - " + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}
	}

	@Override
	public Pessoa pesquisar(String cpf) {

		Connection conn = conexao.getConnection();
		Pessoa pessoa = new Pessoa();

		String sql = "SELECT * FROM PESSOA WHERE CPF = ?";

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, cpf);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				pessoa.setNome(rs.getString("NOME"));
				pessoa.setCpf(rs.getString("CPF"));
				pessoa.setSexo(rs.getString("SEXO"));
				pessoa.setIdade(rs.getInt("IDADE"));
				pessoa.setEmail(rs.getString("EMAIL"));
				pessoa.setEndereco(this.enderecoDAO.pesquisar(rs.getInt("ID_ENDERECO")));
				pessoa.setContaCorrente(this.contaCorrenteDao.pesquisar(rs.getString("CONTA_CORRENTE")));
				pessoa.setContaPoupanca(this.contaPoupancaDao.pesquisar(rs.getString("CONTA_POUPANCA")));
				
			}
		} catch (Exception e) {
			System.out.println("Erro ao pesquisar Pessoa: " + e.getMessage());
		} finally {
			conexao.fecharConexao(conn);
		}
		return pessoa;
	}

	@Override
	public ArrayList<Pessoa> ListarTodos() {

		Connection conn = conexao.getConnection();
		ArrayList<Pessoa> retorno = new ArrayList<Pessoa>();

		String sql = "SELECT * FROM PESSOA";

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Pessoa pessoa = new Pessoa();
				pessoa.setNome(rs.getString("NOME"));
				pessoa.setCpf(rs.getString("CPF"));
				pessoa.setSexo(rs.getString("SEXO"));
				pessoa.setIdade(rs.getInt("IDADE"));
				pessoa.setEmail(rs.getString("EMAIL"));
				pessoa.setEndereco(this.enderecoDAO.pesquisar(rs.getInt("ID_ENDERECO")));
				pessoa.setContaCorrente(this.contaCorrenteDao.pesquisar(rs.getString("CONTA_CORRENTE")));
				pessoa.setContaPoupanca(this.contaPoupancaDao.pesquisar(rs.getString("CONTA_POUPANCA")));
				retorno.add(pessoa);
			}

		} catch (Exception e) {
			System.out.println("Erro ao pesquisar pessoa - " + e.getLocalizedMessage());

		} finally {
			conexao.fecharConexao(conn);
		}
		return retorno;

	}
}
