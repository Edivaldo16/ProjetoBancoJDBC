package Teste;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) {
     
		String numCPF = JOptionPane.showInputDialog("CPF: ");
		if (numCPF == null) {
			JOptionPane.showMessageDialog(null, "Cancelado!");
		}
		String senha = JOptionPane.showInputDialog("Senha: ");
		if (senha == null) {
			JOptionPane.showMessageDialog(null, "Cancelado!");
		}
			
		if (numCPF.equals("00011122233") && senha.equals("FUCTURA")) {
		JOptionPane.showConfirmDialog(null, "Domingo Legal");
			// Login Cliente
		}
	}

}
