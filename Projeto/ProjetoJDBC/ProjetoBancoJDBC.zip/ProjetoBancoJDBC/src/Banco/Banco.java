package Banco;


public class Banco extends menuInicial{

	public static void main(String[] args) {
		
		// Lembrar de inserir "idade" JOption na classe menuInicial
		// Tratar a variável "idade" (18 a 100 anos)
		menuInicial();
	}
}
