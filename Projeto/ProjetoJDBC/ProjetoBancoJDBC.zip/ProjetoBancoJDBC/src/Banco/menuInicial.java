package Banco;

import javax.swing.JOptionPane;

import dao.ContaCorrenteDao;
import dao.ContaPoupancaDao;
import dao.PessoaDao;
import impl.ContaCorrenteDaoImpl;
import impl.ContaPoupancaDaoImpl;
import impl.PessoaDaoImpl;
import model.ContaCorrente;
import model.ContaPoupanca;
import model.Endereco;
import model.Pessoa;
import model.util.Conexao;

public class menuInicial {

	static Conexao conexao = new Conexao();
	static PessoaDao pessoaDao = new PessoaDaoImpl(conexao);
	static ContaCorrenteDao contaCorrenteDao = new ContaCorrenteDaoImpl(conexao);
	static ContaPoupancaDao contaPoupancaDao = new ContaPoupancaDaoImpl(conexao);

	public static void menuInicial() {
		String m = JOptionPane.showInputDialog(
				"                                   ------------------------------------------------------"
						+ "                                            \n                                   |-----Bem vindos ao Banco Fuctura-----|"
						+ "                                            \n                                   |----------------------------------------------------|"
						+ "                                            \n                                   |------Escolha uma das operações-------|"
						+ "                                            \n                                   |----------------------------------------------------|"
						+ "                                            \n                                   |            Opção 1 - Criar Conta               |"
						+ "                                            \n                                   |            Opção 2 - Login                         |"
						+ "                                            \n                                   |            Opção 3 - Sair                            |"
						+ "                                            \n                                   ------------------------------------------------------");

		if (m == null) {
			JOptionPane.showMessageDialog(null, "Cancelado!");
			menuInicial();
		} else if (m.equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Campo Vazio!");
			menuInicial();
		} else {
			try {
				int menuInicial = Integer.parseInt(m);
				switch (menuInicial) {
				case 1:
					criarConta();
					break;
				case 2:
					logarConta();
					break;
				case 3:
					JOptionPane.showMessageDialog(null, "Obrigado por usar os serviços da nossa agência!");
					System.exit(0);
				default:
					JOptionPane.showMessageDialog(null, "Opção inválida!");
					menuInicial();
					break;
				}
			} catch (Exception NumberFormatException) {
				JOptionPane.showMessageDialog(null, "Insira número no devido formado(Ex: 1(número inteiro), 1.15 (número com vírgula)!");
				menuInicial();
			}
		}
	}

	public static void menuCliente(Pessoa p) {
		String m = JOptionPane.showInputDialog(
				"                                   -----------------------------------------------------------------------"
						+ "                                            \n                                   |--------------Bem vindo/a ao Banco Fuctura--------------|"
						+ "                                            \n                                    Cliente: "
						+ p.getNome() + "                                                           "
						+ "                                            \n                                    CPF: "
						+ p.modCpf() + "                                              "
						+ "\n                                    E-mail: " + p.getEmail()
						+ "                                    "
						+ "                                            \n                                   |-----------------------------------------------------------------------|"
						+ "                                            \n                                   |---------------Escolha uma das operações----------------|"
						+ "                                            \n                                   |-----------------------------------------------------------------------|"
						+ "                                            \n                                   |            Opção 1 - Mudar Dados Cadastrais               |"
						+ "                                            \n                                   |            Opção 2 - Acessar Conta Corrente                |"
						+ "                                            \n                                   |            Opção 3 - Acessar Conta Poupança               |"
						+ "                                            \n                                   |            Opção 4 - Sair                                                    |"
						+ "                                            \n                                   -----------------------------------------------------------------------");
		int menu = Integer.parseInt(m);
		if (m == null) {
			JOptionPane.showMessageDialog(null, "Cancelado!");
			menuInicial();
		} else if (m.equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Campo Vazio!");
			menuInicial();
		}
		switch (menu) {
		case 1:
			modificarCadastro(p);
			break;
		case 2:
			acessarContaCorrente(p);
			break;
		case 3:
		    acessarContaPoupanca(p);
			break;
		case 4:
			JOptionPane.showMessageDialog(null, "Obrigado por usar os serviços da nossa agência!");
			menuInicial();
		default:
			JOptionPane.showMessageDialog(null, "Opção inválida!!");
			menuInicial();
			break;

		}
	}

	// Método Gerente
	public static void menuGerente(Pessoa p) {

		int menu = Integer.parseInt(JOptionPane.showInputDialog(
				"                                   -------------------------------------------------------------------"
						+ "                                            \n                                   |---------------Gerência Banco Fuctura-----------------|"
						+ "                                            \n                                   |------------------------------------------------------------------|"
						+ "                                            \n                                   |-------------Escolha uma das operações--------------|"
						+ "                                            \n                                   |------------------------------------------------------------------|"
						+ "                                            \n                                   |            Opção 1 - Criar Conta                                 |"
						+ "                                            \n                                   |            Opção 2 - Encontrar Dados Cadastrais    |"
						+ "                                            \n                                   |            Opção 3 - Listar Contas                             |"
						+ "                                            \n                                   |            Opção 4 - Excluir Conta                             |"
						+ "                                            \n                                   |            Opção 5 - Sair                                              |"
						+ "                                            \n                                   -------------------------------------------------------------------"
						+ ""));

		switch (menu) {
		case 1:
			criarContaGerente(p);
			break;
		case 2:
			logarContaGerente(p);
			break;
		case 3:
			listarContas(p);
			break;
		case 4:
			excluirContaGerente(p);
			break;
		case 5:
			JOptionPane.showMessageDialog(null, "Obrigado por usar os serviços da nossa agência!");
			menuInicial();
		default:
			JOptionPane.showMessageDialog(null, "Opção inválida!!");
			menuGerente(p);
			break;
		}
	}

	public static void criarConta() {

		Pessoa pessoa = new Pessoa();
		Endereco endereco = new Endereco();
		
		Pessoa p = null;

		pessoa.setNome(JOptionPane.showInputDialog("Nome: "));
		if (pessoa.getNome().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Campo vazio ou caracteres alfanuméricos. Nome deve ser composto por letras!");
			menuInicial();
		}
		pessoa.setCpf(JOptionPane.showInputDialog("CPF: "));
		p = pessoaDao.pesquisar(pessoa.getCpf());
		if (pessoa.getCpf().isEmpty()) {
			JOptionPane.showMessageDialog(null, "CPF campo vazio!");
			menuInicial();
		} else if (pessoa.getCpf().equals("00011122233")) {
			JOptionPane.showMessageDialog(null, "CPF já existente no banco de dados!");
			menuInicial();
		} else if (pessoa.getCpf().length() != 11) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuInicial();
		} else if (!pessoa.getCpf().matches("[0-9]*")) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuInicial();
		} else if(pessoa.getCpf().equals(p.getCpf())) {
			JOptionPane.showMessageDialog(null, "CPF já cadastrado!");
			menuInicial();
		}
		pessoa.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Idade: ")));
		if (Integer.toString(pessoa.getIdade()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Idade está com campo vazio!");
			menuInicial();
		} else if(!(pessoa.getIdade() >= 18 && pessoa.getIdade() <= 100)) {
			JOptionPane.showMessageDialog(null, "Idade digitada está fora do range permitido!");
			menuInicial();
		} 
		else if (!(Integer.toString(pessoa.getIdade()).matches("[0-9]*"))) {
			JOptionPane.showMessageDialog(null, "Idade deve ser composto por digitos numéricos!");
			menuInicial();
		} 
		pessoa.setSexo(JOptionPane.showInputDialog("Sexo (MA/FE): ").toUpperCase());
		if (pessoa.getSexo().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Sexo está com campo vazio!");
			menuInicial();
		} else if(!(pessoa.getSexo().equals("MA") || pessoa.getSexo().equals("FE"))){
			JOptionPane.showMessageDialog(null, "Digite MA para Masculino e FE para Feminino!");
			menuInicial();
		}
		pessoa.setEmail(JOptionPane.showInputDialog("E-mail: "));
		if (pessoa.getEmail().isEmpty()) {
			JOptionPane.showMessageDialog(null, "E-mail está com campo vazio!");
			menuInicial();
		}

		endereco.setRua(JOptionPane.showInputDialog("Rua: ").toUpperCase());
		if (endereco.getRua().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Rua está com campo vazio!");
			menuInicial();
		}
		endereco.setNumero(Integer.parseInt(JOptionPane.showInputDialog("Número: ")));
		if (Integer.toString(endereco.getNumero()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Número está com campo vazio!");
			menuInicial();
		}
		endereco.setComplemento(JOptionPane.showInputDialog("Complemento: ").toUpperCase());
		if (endereco.getComplemento().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Complemento está com campo vazio!");
			menuInicial();
		}
		endereco.setCidade(JOptionPane.showInputDialog("Cidade: ").toUpperCase());
		if (endereco.getCidade().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Cidade está com campo vazio!");
			menuInicial();
		}
		endereco.setEstado(JOptionPane.showInputDialog("Estado: ").toUpperCase());
		if (endereco.getEstado().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Estado está com campo vazio!");
			menuInicial();
		}

		pessoa.setEndereco(endereco);

		ContaCorrente cc = new ContaCorrente();
		ContaPoupanca cp = new ContaPoupanca(cc);

		pessoa.setEndereco(endereco);
		pessoa.setContaCorrente(cc);
		pessoa.setContaPoupanca(cp);

		pessoaDao.salvar(pessoa);

		int menu = Integer.parseInt(JOptionPane.showInputDialog(null, "Confira seus dados!" + "\nConta Corrente: "
				+ pessoa.getContaCorrente().getNumeroConta() + "\nConta Poupança: " + pessoa.getContaPoupanca().getNumeroConta() + "\nSenha: " + pessoa.getContaCorrente().getSenha()
				+ "\nNome: " + pessoa.getNome() + "\nCPF: " + pessoa.modCpf() + "\nIdade: " + pessoa.getIdade() 
				+ "\nSexo: " + pessoa.getSexo()
				+ "\nE-mail: " + pessoa.getEmail() + "\nRua: " + pessoa.getEndereco().getRua() + "\nNúmero: " + pessoa.getEndereco().getNumero()
				+ "\nComplemento: " + pessoa.getEndereco().getComplemento() + "\nCidade: " + pessoa.getEndereco().getCidade()
				+ "\nEstado: " + pessoa.getEndereco().getEstado()
				+ "\nSua Conta foi criada com sucesso"
				+ "\n-------------------------------------------------" 
				+ "\n|       1 - Mudar Dados Cadastrais    |"
				+ "\n|       2 - Sair                                        |"
				+ "\n-------------------------------------------------" + "\n"));
		switch (menu) {
		case 1:
			modCadastro(pessoa);
			break;
		case 2:
			JOptionPane.showMessageDialog(null, "Obrigado por usar os serviços da nossa agência!");
			menuInicial();
		default:
			JOptionPane.showMessageDialog(null, "Opção inválida!!");
			menuInicial();
			break;
		}
	}

	public static void criarContaGerente(Pessoa p) {

		Pessoa pessoa = new Pessoa();

		Endereco endereco = new Endereco();

		pessoa.setNome(JOptionPane.showInputDialog("Nome: "));
		if (pessoa.getNome() == null) {
			JOptionPane.showMessageDialog(null, "Cancelado!");
			menuGerente(p);
		} else if (pessoa.getNome().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Campo Vazio!");
			menuGerente(p);
		} else if (!pessoa.getNome().matches("[A-Z]*")) {
			JOptionPane.showMessageDialog(null, "Nome deve ser composto por letras!");
			menuGerente(p);
		}
		pessoa.setCpf(JOptionPane.showInputDialog("CPF: "));
		Pessoa t = pessoaDao.pesquisar(pessoa.getCpf());
		if (pessoa.getCpf().isEmpty()) {
			JOptionPane.showMessageDialog(null, "CPF campo vazio!");
			menuGerente(p);
		} else if (pessoa.getCpf().equals("00011122233")) {
			JOptionPane.showMessageDialog(null, "CPF já existente no banco de dados!");
			menuGerente(p);
		} else if (pessoa.getCpf().length() != 11) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuGerente(p);
		} else if (!pessoa.getCpf().matches("[0-9]*")) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuGerente(p);
		} else if(pessoa.getCpf().equals(t.getCpf())) {
			JOptionPane.showMessageDialog(null, "CPF já cadastrado!");
			menuGerente(p);
		}
		pessoa.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Idade: ")));
		if (Integer.toString(pessoa.getIdade()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Idade está com campo vazio!");
			menuGerente(p);
		} else if(!(pessoa.getIdade() >= 18 && pessoa.getIdade() <= 100)) {
			JOptionPane.showMessageDialog(null, "Idade digitada está fora do range permitido!");
			menuGerente(p);
		} 
		else if (!(Integer.toString(pessoa.getIdade()).matches("[0-9]*"))) {
			JOptionPane.showMessageDialog(null, "Idade deve ser composto por digitos numéricos!");
			menuGerente(p);
		}
		pessoa.setSexo(JOptionPane.showInputDialog("Sexo (MA/FE): ").toUpperCase());
		if (pessoa.getSexo().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Sexo está com campo vazio!");
			menuGerente(p);
		} else if(!(pessoa.getSexo().equals("MA") || pessoa.getSexo().equals("FE"))){
			JOptionPane.showMessageDialog(null, "Digite MA para Masculino e FE para Feminino!");
			menuGerente(p);
		}
		pessoa.setEmail(JOptionPane.showInputDialog("E-mail: "));
		if (pessoa.getEmail().isEmpty()) {
			JOptionPane.showMessageDialog(null, "E-mail está com campo vazio!");
			menuGerente(p);
		}

		endereco.setRua(JOptionPane.showInputDialog("Rua: ").toUpperCase());
		if (endereco.getRua().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Rua está com campo vazio!");
			menuGerente(p);
		}
		endereco.setNumero(Integer.valueOf(JOptionPane.showInputDialog("Número: ")));
		if (Integer.toString(endereco.getNumero()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Número está com campo vazio!");
			menuGerente(p);
		}
		endereco.setComplemento(JOptionPane.showInputDialog("Complemento: ").toUpperCase());
		if (endereco.getComplemento().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Complemento está com campo vazio!");
			menuGerente(p);
		}
		endereco.setCidade(JOptionPane.showInputDialog("Cidade: ").toUpperCase());
		if (endereco.getCidade().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Cidade está com campo vazio!");
			menuGerente(p);
		}
		endereco.setEstado(JOptionPane.showInputDialog("Estado: ").toUpperCase());
		if (endereco.getEstado().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Estado está com campo vazio!");
			menuGerente(p);
		}

		pessoa.setEndereco(endereco);

		ContaCorrente cc = new ContaCorrente();
		ContaPoupanca cp = new ContaPoupanca(cc);

		pessoa.setEndereco(endereco);
		pessoa.setContaCorrente(cc);
		pessoa.setContaPoupanca(cp);

		pessoaDao.salvar(pessoa);

		int menu = Integer.parseInt(JOptionPane.showInputDialog(null, "Confira seus dados!" + "\nConta Corrente: "
				+ pessoa.getContaCorrente().getNumeroConta() + "\nConta Poupança: " + pessoa.getContaPoupanca().getNumeroConta() + "\nSenha: " + pessoa.getContaCorrente().getSenha()
				+ "\nNome: " + pessoa.getNome() + "\nCPF: " + pessoa.modCpf() + "\nIdade: " + pessoa.getIdade()
				+ "\nSexo: " + pessoa.getSexo()
				+ "\nE-mail: " + pessoa.getEmail() + "\nRua: " + pessoa.getEndereco().getRua() + "\nNúmero: " + pessoa.getEndereco().getNumero()
				+ "\nComplemento: " + pessoa.getEndereco().getComplemento() + "\nCidade: " + pessoa.getEndereco().getCidade()
				+ "\nEstado: " + pessoa.getEndereco().getEstado()
				+ "\nSua Conta foi criada com sucesso"
				+ "\n-------------------------------------------------" 
				+ "\n|       1 - Mudar Dados Cadastrais    |"
				+ "\n|       2 - Sair                                        |"
				+ "\n-------------------------------------------------" + "\n"));
		menuGerente(p);
	}

	public static void logarConta() {

		Pessoa p = null;

		String numCPF = JOptionPane.showInputDialog("CPF: ");
		if (numCPF == null) {
			JOptionPane.showMessageDialog(null, "Cancelado!");
			menuInicial();
		} else if (numCPF.equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Campo Vazio!");
			menuInicial();
		} else if (numCPF.length() != 11) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuInicial();
		} else if (!numCPF.matches("[0-9]*")) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuInicial();
		}
		String senha = JOptionPane.showInputDialog("Senha: ");
		if (senha == null) {
			JOptionPane.showMessageDialog(null, "Cancelado!");
			menuInicial();
		} else if (senha.equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Campo Vazio!");
			menuInicial();
		}

		p = pessoaDao.pesquisar(numCPF);
		
		if (numCPF.equals("00011122233") && senha.equals("FUCTURA")) {
			menuGerente(p);
		} 
		else if (numCPF.equals(p.getCpf()) && senha.equals(p.getContaCorrente().getSenha())) {
			menuCliente(p);
		} else {
			JOptionPane.showMessageDialog(null, "CPF e/ou senha incorreto(s)!");
			menuInicial();
		}
	}

	public static void logarContaGerente(Pessoa p) {

		Pessoa pessoa = null;

		String numCPF = JOptionPane.showInputDialog("CPF: ");
		if (numCPF.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Campo vazio. CPF deve ser composto por 11 digitos numéricos!");
			menuGerente(p);
		}

		else if (numCPF.length() != 11) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuGerente(p);
		} else if (!numCPF.matches("[0-9]*")) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuGerente(p);
		}

		pessoa = pessoaDao.pesquisar(numCPF);
		// Login Gerente
		if (numCPF.equals("00011122233")) {
			JOptionPane.showMessageDialog(null, "Gerente já está logado!");
			menuGerente(p);
		// Login Cliente
		} else if (pessoa != null) {
			int menu = Integer.parseInt(JOptionPane.showInputDialog(null, "Confira seus dados!" + "\nConta Corrente: "
					+ pessoa.getContaCorrente().getNumeroConta() + "\nConta Poupança: " + pessoa.getContaPoupanca().getNumeroConta() + "\nSenha: " + pessoa.getContaCorrente().getSenha()
					+ "\nNome: " + pessoa.getNome() + "\nCPF: " + pessoa.modCpf() + "\nIdade: " + pessoa.getIdade() 
					+ "\nSexo: " + pessoa.getSexo()
					+ "\nE-mail: " + pessoa.getEmail() + "\nRua: " + pessoa.getEndereco().getRua() + "\nNúmero: " + pessoa.getEndereco().getNumero()
					+ "\nComplemento: " + pessoa.getEndereco().getComplemento() + "\nCidade: " + pessoa.getEndereco().getCidade()
					+ "\nEstado: " + pessoa.getEndereco().getEstado()
					+ "\nSua Conta foi criada com sucesso"
					+ "\n-------------------------------------------------" 
					+ "\n|       1 - Mudar Dados Cadastrais    |"
					+ "\n|       2 - Sair                                        |"
					+ "\n-------------------------------------------------" + "\n"));		
			switch (menu) {
			case 1:
				modificarCadastroGerente(pessoa);
				break;
			case 2:
				JOptionPane.showMessageDialog(null, "Obrigado por usar os serviços da nossa agência!");
				menuGerente(pessoa);
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida!!");
				menuGerente(pessoa);
				break;
			}
		} else {
			JOptionPane.showMessageDialog(null, "CPF incorreto e/ou conta não existe!");
			menuGerente(p);
		}
	}

	public static void modCadastro(Pessoa p) {

		Pessoa pessoa = new Pessoa();
		Endereco endereco = new Endereco();

		pessoa.setNome(JOptionPane.showInputDialog("Nome: "));
		if (pessoa.getNome().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Campo vazio ou caracteres alfanuméricos. Nome deve ser composto por letras!");
			menuInicial();
		}
		pessoa.setCpf(JOptionPane.showInputDialog("CPF: "));
        Pessoa t = pessoaDao.pesquisar(pessoa.getCpf());
		if (pessoa.getCpf().isEmpty()) {
			JOptionPane.showMessageDialog(null, "CPF campo vazio!");
			menuInicial();
		} else if (pessoa.getCpf().equals("00011122233")) {
			JOptionPane.showMessageDialog(null, "CPF já existente no banco de dados!");
			menuInicial();
		} else if (pessoa.getCpf().length() != 11) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuInicial();
		} else if (!pessoa.getCpf().matches("[0-9]*")) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuInicial();
		} else if(pessoa.getCpf().equals(t.getCpf())) {
			JOptionPane.showMessageDialog(null, "CPF já está cadastrado! Se este for seu CPF, modifique no Menu Conta Corrente ou entre em contato com a gerência!");
			menuInicial();
		}
		pessoa.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Idade: ")));
		if (Integer.toString(pessoa.getIdade()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Idade está com campo vazio!");
			menuInicial();
		} else if(!(pessoa.getIdade() >= 18 && pessoa.getIdade() <= 100)) {
			JOptionPane.showMessageDialog(null, "Idade digitada está fora do range permitido!");
			menuInicial();
		} 
		else if (!(Integer.toString(pessoa.getIdade()).matches("[0-9]*"))) {
			JOptionPane.showMessageDialog(null, "Idade deve ser composto por digitos numéricos!");
			menuInicial();
		}
		pessoa.setSexo(JOptionPane.showInputDialog("Sexo (MA/FE): ").toUpperCase());
		if (pessoa.getSexo().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Sexo está com campo vazio!");
			menuInicial();
		} else if(!(pessoa.getSexo().equals("MA") || pessoa.getSexo().equals("FE"))){
			JOptionPane.showMessageDialog(null, "Digite MA para Masculino e FE para Feminino!");
			menuInicial();
		}
		pessoa.setEmail(JOptionPane.showInputDialog("E-mail: "));
		if (pessoa.getEmail().isEmpty()) {
			JOptionPane.showMessageDialog(null, "E-mail está com campo vazio!");
			menuInicial();
		}
		
		endereco.setRua(JOptionPane.showInputDialog("Rua: ").toUpperCase());
		if (endereco.getRua().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Rua está com campo vazio!");
			menuInicial();
		}
		endereco.setNumero(Integer.parseInt(JOptionPane.showInputDialog("Número: ")));
		System.out.println("Tipo endereço: " + endereco.getNumero().getClass().getSimpleName());
		if (Integer.toString(endereco.getNumero()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Número está com campo vazio!");
			menuInicial();
		}
		endereco.setComplemento(JOptionPane.showInputDialog("Complemento: ").toUpperCase());
		if (endereco.getComplemento().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Complemento está com campo vazio!");
			menuInicial();
		}
		endereco.setCidade(JOptionPane.showInputDialog("Cidade: ").toUpperCase());
		if (endereco.getCidade().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Cidade está com campo vazio!");
			menuInicial();
		}
		endereco.setEstado(JOptionPane.showInputDialog("Estado: ").toUpperCase());
		if (endereco.getEstado().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Estado está com campo vazio!");
			menuInicial();
		}

		pessoa.setEndereco(endereco);

		double saldoCc = p.getContaCorrente().getSaldo();
		double saldoCp = p.getContaPoupanca().getSaldo();

		// IMPORTANTE
		ContaCorrente b = new ContaCorrente();
		ContaPoupanca c = new ContaPoupanca(b);
		
		b.setSaldo(saldoCc);
		c.setSaldo(saldoCp);
		
		pessoa.setEndereco(endereco);
		pessoa.setContaCorrente(b);
		pessoa.setContaPoupanca(c);

		pessoaDao.remover(p.getCpf());
		pessoaDao.salvar(pessoa);

		int menu = Integer.parseInt(JOptionPane.showInputDialog(null, "Conta modificada com sucesso!"
				+ "\nConfira seus dados!" + "\nConta Corrente: " + pessoa.getContaCorrente().getNumeroConta() + "\nConta Poupança: "
				+ pessoa.getContaPoupanca().getNumeroConta() + "\nSenha: " + pessoa.getContaCorrente().getSenha() + "\nNome: " + pessoa.getNome() + "\nCPF: "
				+ pessoa.modCpf() + "\nIdade: " + pessoa.getIdade() + "\nSexo: " + pessoa.getSexo()
				+ "\nE-mail: " + pessoa.getEmail() 
				+ "\nRua: " + pessoa.getEndereco().getRua() + "\nNúmero: " + pessoa.getEndereco().getNumero() 
				+ "\nComplemento: " + pessoa.getEndereco().getComplemento() + "\nCidade: " + pessoa.getEndereco().getCidade()
				+ "\nEstado: " + pessoa.getEndereco().getEstado()
				+ "\n"
				+ "\n-------------------------------------------------"
				+ "\n|       1 - Mudar Dados Cadastrais    |"
				+ "\n|       2 - Sair                                        |"
				+ "\n-------------------------------------------------" + "\n"));
		switch (menu) {
		case 1:
			modCadastro(pessoa);
			break;
		case 2:
			JOptionPane.showMessageDialog(null, "Obrigado por usar os serviços da nossa agência!");
			menuInicial();
		default:
			JOptionPane.showMessageDialog(null, "Opção inválida!!");
			menuInicial();
			break;
		}
	}

	public static void modificarCadastro(Pessoa p) {

		Pessoa pessoa = new Pessoa();
		Endereco endereco = new Endereco();

		pessoa.setNome(JOptionPane.showInputDialog("Nome: "));
		if (pessoa.getNome().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Campo vazio ou caracteres alfanuméricos. Nome deve ser composto por letras!");
			menuCliente(p);
		}
		pessoa.setCpf(p.getCpf());
		pessoa.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Idade: ")));
		if (Integer.toString(pessoa.getIdade()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Idade está com campo vazio!");
			menuCliente(p);
		} else if(!(pessoa.getIdade() >= 18 && pessoa.getIdade() <= 100)) {
			JOptionPane.showMessageDialog(null, "Idade digitada está fora do range permitido!");
			menuCliente(p);
		}
		pessoa.setEmail(JOptionPane.showInputDialog("E-mail: "));
		if (pessoa.getEmail().isEmpty()) {
			JOptionPane.showMessageDialog(null, "E-mail está com campo vazio!");
			menuCliente(p);
		}
		pessoa.setSexo(JOptionPane.showInputDialog("Sexo (MA/FE): ").toUpperCase());
		if (pessoa.getSexo().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Sexo está com campo vazio!");
			menuCliente(p);
		} else if(!(pessoa.getSexo().equals("MA") || pessoa.getSexo().equals("FE"))){
			JOptionPane.showMessageDialog(null, "Digite MA para Masculino e FE para Feminino!");
			menuCliente(p);
		}

		endereco.setRua(JOptionPane.showInputDialog("Rua: ").toUpperCase());
		if (endereco.getRua().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Rua está com campo vazio!");
			menuCliente(p);
		}
		endereco.setNumero(Integer.valueOf(JOptionPane.showInputDialog("Número: ")));
		if (Integer.toString(endereco.getNumero()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Número está com campo vazio!");
			menuCliente(p);
		}
		endereco.setComplemento(JOptionPane.showInputDialog("Complemento: ").toUpperCase());
		if (endereco.getComplemento().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Complemento está com campo vazio!");
			menuCliente(p);
		}
		endereco.setCidade(JOptionPane.showInputDialog("Cidade: ").toUpperCase());
		if (endereco.getCidade().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Cidade está com campo vazio!");
			menuCliente(p);
		}
		endereco.setEstado(JOptionPane.showInputDialog("Estado: ").toUpperCase());
		if (endereco.getEstado().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Estado está com campo vazio!");
			menuCliente(p);
		}
		
		pessoa.setEndereco(endereco);
		pessoa.setContaCorrente(p.getContaCorrente());
		pessoa.setContaPoupanca(p.getContaPoupanca());

		pessoaDao.remover(p.getCpf());
		pessoaDao.salvar(pessoa);

		int menu = Integer.parseInt(JOptionPane.showInputDialog(null, "Conta modificada com sucesso!"
				+ "\nConfira seus dados!" + "\nConta Corrente: " + pessoa.getContaCorrente().getNumeroConta() + "\nConta Poupança: "
				+ pessoa.getContaPoupanca().getNumeroConta() + "\nSenha: " + pessoa.getContaCorrente().getSenha() + "\nNome: " + pessoa.getNome() 
				+ "\nCPF: "	+ pessoa.modCpf() + "\nIdade: " + pessoa.getIdade()
				+ "\nSexo: " + pessoa.getSexo()
				+ "\nE-mail: " + pessoa.getEmail() + "\nRua: " + pessoa.getEndereco().getRua()
				+ "\nNúmero: " + pessoa.getEndereco().getNumero() + "\nComplemento: " + pessoa.getEndereco().getComplemento()
				+ "\nCidade: " + pessoa.getEndereco().getCidade() + "\nEstado: " + pessoa.getEndereco().getEstado()
 				+ "\n"
				+ "\n-------------------------------------------------" 
				+ "\n|       1 - Mudar Dados Cadastrais    |"
				+ "\n|       2 - Sair                                        |"
				+ "\n-------------------------------------------------" + "\n"));

		switch (menu) {
		case 1:
			modificarCadastro(pessoa);
			break;
		case 2:
			JOptionPane.showMessageDialog(null, "Obrigado por usar os serviços da nossa agência!");
			menuCliente(pessoa);
		default:
			JOptionPane.showMessageDialog(null, "Opção inválida!!");
			menuCliente(pessoa);
			break;
		}
			}

	public static void modificarCadastroGerente(Pessoa p) {

		Pessoa pessoa = new Pessoa();
		Endereco endereco = new Endereco();

		pessoa.setNome(JOptionPane.showInputDialog("Nome: "));

		if (pessoa.getNome().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Campo vazio ou caracteres alfanuméricos. Nome deve ser composto por letras!");
			menuGerente(p);
		}
		pessoa.setCpf(JOptionPane.showInputDialog("CPF: "));
		if (pessoa.getCpf().isEmpty()) {
			JOptionPane.showMessageDialog(null, "CPF campo vazio!");
			menuGerente(p);
		} else if (pessoa.getCpf().equals("00011122233")) {
			JOptionPane.showMessageDialog(null, "CPF já existente no banco de dados!");
			menuGerente(p);
		} else if (pessoa.getCpf().length() != 11) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuGerente(p);
		} else if (!pessoa.getCpf().matches("[0-9]*")) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuGerente(p);
		} else if (pessoa.getCpf().equals(p.getCpf())) {
			JOptionPane.showMessageDialog(null, "CPF já cadastrado!");
			menuGerente(p);
		}
		pessoa.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Idade: ")));
		if (Integer.toString(pessoa.getIdade()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Idade está com campo vazio!");
			menuGerente(p);
		} else if(!(pessoa.getIdade() >= 18 && pessoa.getIdade() <= 100)) {
			JOptionPane.showMessageDialog(null, "Idade digitada está fora do range permitido!");
			menuGerente(p);
		}
		pessoa.setSexo(JOptionPane.showInputDialog("Sexo (MA/FE): ").toUpperCase());
		if (pessoa.getSexo().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Sexo está com campo vazio!");
			menuGerente(p);
		} else if(!(pessoa.getSexo().equals("MA") || pessoa.getSexo().equals("FE"))){
			JOptionPane.showMessageDialog(null, "Digite MA para Masculino e FE para Feminino!");
			menuGerente(p);
		}
		pessoa.setEmail(JOptionPane.showInputDialog("E-mail: "));
		if (pessoa.getEmail().isEmpty()) {
			JOptionPane.showMessageDialog(null, "E-mail está com campo vazio!");
			menuGerente(p);
		}

		endereco.setRua(JOptionPane.showInputDialog("Rua: ").toUpperCase());
		if (endereco.getRua().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Rua está com campo vazio!");
			menuGerente(p);
		}
		endereco.setNumero(Integer.valueOf(JOptionPane.showInputDialog("Número: ")));
		if (Integer.toString(endereco.getNumero()).isEmpty()) {
			JOptionPane.showMessageDialog(null, "Número está com campo vazio!");
			menuGerente(p);
		}
		endereco.setComplemento(JOptionPane.showInputDialog("Complemento: ").toUpperCase());
		if (endereco.getComplemento().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Complemento está com campo vazio!");
			menuGerente(p);
		}
		endereco.setCidade(JOptionPane.showInputDialog("Cidade: "));
		if (endereco.getCidade().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Cidade está com campo vazio!");
			menuGerente(p);
		}
		endereco.setEstado(JOptionPane.showInputDialog("Estado: ").toUpperCase());
		if (endereco.getEstado().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Estado está com campo vazio!");
			menuGerente(p);
		}
		
		pessoa.setEndereco(endereco);
		pessoa.setContaCorrente(p.getContaCorrente());
		pessoa.setContaPoupanca(p.getContaPoupanca());

		pessoaDao.remover(p.getCpf());
		pessoaDao.salvar(pessoa);
		
		int menu = Integer.parseInt(JOptionPane.showInputDialog(null, "Conta modificada com sucesso!"
				+ "\nConfira os dados!" + "\nConta Corrente: " + pessoa.getContaCorrente().getNumeroConta() + "\nConta Poupança: "
				+ pessoa.getContaPoupanca().getNumeroConta() + "\nSenha: " + pessoa.getContaCorrente().getSenha() + "\nNome: " + pessoa.getNome() 
				+ "\nCPF: " + pessoa.modCpf() + "\nIdade: " + pessoa.getIdade() 
				+ "\nSexo: " + pessoa.getSexo()
				+ "\nE-mail: " + pessoa.getEmail() + "\nRua: " + pessoa.getEndereco().getRua()
				+ "\nNúmero: " + pessoa.getEndereco().getNumero() + "\nComplemento: " + pessoa.getEndereco().getComplemento()
				+ "\nCidade: " + pessoa.getEndereco().getCidade() + "\nEstado: " + pessoa.getEndereco().getEstado()
				+ "\n"
				+ "\n-------------------------------------------------" 
				+ "\n|       1 - Mudar Dados Cadastrais    |"
				+ "\n|       2 - Sair                                        |"
				+ "\n-------------------------------------------------" + "\n"));

		switch (menu) {
		case 1:
			modificarCadastroGerente(pessoa);
			break;
		case 2:
			JOptionPane.showMessageDialog(null, "Obrigado por usar os serviços da nossa agência!");
			menuGerente(pessoa);
		default:
			JOptionPane.showMessageDialog(null, "Opção inválida!!");
			menuGerente(pessoa);
			break;
		}
	}
	
	public static void excluirContaGerente(Pessoa p) {
		
		Pessoa pessoa = null;

		String numCPF = JOptionPane.showInputDialog("CPF: ");
		if (numCPF.isEmpty()) {
			JOptionPane.showMessageDialog(null, "CPF campo vazio!");
			menuGerente(p);
		} else if (numCPF.equals("00011122233")) {
			JOptionPane.showMessageDialog(null, "CPF já existente no banco de dados!");
			menuGerente(p);
		} else if (numCPF.length() != 11) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuGerente(p);
		} else if (!numCPF.matches("[0-9]*")) {
			JOptionPane.showMessageDialog(null, "CPF deve ser composto por 11 digitos numéricos!");
			menuGerente(p);
		}
		
		pessoa = pessoaDao.pesquisar(numCPF);
		
		if (pessoa.getCpf() != null) {
			int menu = Integer.parseInt(JOptionPane.showInputDialog(null, "Conta a ser excluida!"
					+ "\nConfira os dados!" + "\nConta Corrente: " + pessoa.getContaCorrente().getNumeroConta() + "\nConta Poupança: "
					+ pessoa.getContaPoupanca().getNumeroConta() + "\nSenha: " + pessoa.getContaCorrente().getSenha() + "\nNome: " + pessoa.getNome() 
					+ "\nCPF: " + pessoa.modCpf() + "\nIdade: " + pessoa.getIdade() 
					+ "\nSexo: " + pessoa.getSexo()
					+ "\nE-mail: " + pessoa.getEmail() + "\nRua: " + pessoa.getEndereco().getRua()
					+ "\nNúmero: " + pessoa.getEndereco().getNumero() + "\nComplemento: " + pessoa.getEndereco().getComplemento()
					+ "\nCidade: " + pessoa.getEndereco().getCidade() + "\nEstado: " + pessoa.getEndereco().getEstado()
					+ "\n"
					+ "\n-------------------------------------------------" 
					+ "\n|       1 - Excluir Dados Cadastrais    |"
					+ "\n|       2 - Sair                                        |"
					+ "\n-------------------------------------------------" + "\n"));
			switch (menu) {
			case 1:
				pessoaDao.remover(pessoa.getCpf());
				JOptionPane.showInternalMessageDialog(null, "Cadastro removido com sucesso!");
				menuGerente(p);
				break;
			case 2:
				JOptionPane.showMessageDialog(null, "Obrigado por usar os serviços da nossa agência!");
				menuGerente(p);
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida!!");
				menuGerente(p);
				break;
			}
		}else {
			JOptionPane.showInternalMessageDialog(null, "Não há registro do CPF no banco de dados!");
			menuGerente(p);
		}
	}

	public static void listarContas(Pessoa t) {

		if (pessoaDao.ListarTodos().size() > 0) {
			for (Pessoa p : pessoaDao.ListarTodos()) {
				StringBuffer sb = new StringBuffer(p.getContaCorrente().getNumeroConta());
				String a = sb.insert(6, "-").toString();
				JOptionPane.showMessageDialog(null,
						"\nConta Corrente: " + p.getContaCorrente().getNumeroConta() + "\nConta Poupança: " + a
								+ "\nSenha: " + p.getContaCorrente().getSenha() + "\nNome: " + p.getNome() + "\nCPF: "
								+ p.modCpf() + "\nE-mail: " + p.getEmail() + "\nRua: " + p.getEndereco().getRua()
								+ "\nNúmero: " + p.getEndereco().getNumero() + "\nComplemento: "
								+ p.getEndereco().getComplemento() + "\nCidade: " + p.getEndereco().getCidade()
								+ "\nEstado: " + p.getEndereco().getEstado());
			}
		} else {
			JOptionPane.showMessageDialog(null, "Não há contas cadastradas!");
		}
		menuGerente(t);
	}

	public static void acessarContaCorrente(Pessoa p) {
		{

			int menu = Integer.parseInt(JOptionPane.showInputDialog(
					"                                   ------------------------------------------------------"
							+ "                                            \n                                   |-----Bem vindo/a ao Banco Fuctura-----|"
							+ "                                            \n                                    Cliente: "
							+ p.getNome()
							+ "                  \n                                   ContaCorrente:  "
							+ p.getContaCorrente().getNumeroConta()
							+ "                                            \n                                    CPF: "
							+ p.modCpf() + " "
							+ "                                            \n                                   |-----------------------------------------------------|"
							+ "                                            \n                                   |-------Escolha uma das operações-------|"
							+ "                                            \n                                   |-----------------------------------------------------|"
							+ "                                            \n                                   |            Opção 1 - Saldo                           |"
							+ "                                            \n                                   |            Opção 2 - Sacar                           |"
							+ "                                            \n                                   |            Opção 3 - Depositar                    |"
							+ "                                            \n                                   |            Opção 4 - Transferir                   |"
							+ "                                            \n                                   |            Opção 5 - Aplicar                         |"
							+ "                                            \n                                   |            Opção 6 - Sair                              |"
							+ "                                            \n                                   ------------------------------------------------------"));
			switch (menu) {
			case 1:
				p.getContaCorrente().mostrarSaldo();
				acessarContaCorrente(p);
				break;
			case 2:
				p.getContaCorrente().sacar();
				Pessoa pessoa = p;
				pessoaDao.remover(p.getCpf());
				pessoaDao.salvar(pessoa);
				acessarContaCorrente(pessoa);
				break;
			case 3:
				p.getContaCorrente().depositar();
				Pessoa pe = p;
				pessoaDao.remover(p.getCpf());
				pessoaDao.salvar(pe);
				acessarContaCorrente(pe);
				break;
			case 4:
				ContaCorrente teste = p.getContaCorrente().transferir(pessoaDao.ListarTodos());
				//ContaCorrente teste2 = contaCorrenteDao.pesquisar(teste.getNumeroConta());
				contaCorrenteDao.alterar(teste);
				Pessoa p1 = p;
				pessoaDao.remover(p.getCpf());
				pessoaDao.salvar(p1);
				acessarContaCorrente(p1);
				break;
			case 5:
				p.getContaCorrente().aplicar(p.getContaPoupanca());
				Pessoa p2 = p;
				pessoaDao.remover(p.getCpf());
				pessoaDao.salvar(p2);
				acessarContaCorrente(p2);
				break;
			case 6:
				menuCliente(p);
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida!!");
				menuCliente(p);
				break;
			}
		}
	}

	public static void acessarContaPoupanca(Pessoa p) {

		{
			int menu = Integer.parseInt(JOptionPane.showInputDialog(
					"                                   ------------------------------------------------------"
							+ "                                            \n                                   |-----Bem vindo/a ao Banco Fuctura-----|"
							+ "                                            \n                                    Cliente: "
							+ p.getNome()
							+ "                  \n                                   ContaPoupança:  "
							+ p.getContaPoupanca().getNumeroConta()
							+ "                                            \n                                    CPF: "
							+ p.modCpf() + " "
							+ "                                            \n                                   |-----------------------------------------------------|"
							+ "                                            \n                                   |-------Escolha uma das operações-------|"
							+ "                                            \n                                   |-----------------------------------------------------|"
							+ "                                            \n                                   |            Opção 1 - Saldo                           |"
							+ "                                            \n                                   |            Opção 2 - Transferir                   |"
							+ "                                            \n                                   |            Opção 3 - Resgatar                      |"
							+ "                                            \n                                   |            Opção 4 - Sair                              |"
							+ "                                            \n                                   ------------------------------------------------------"));
			switch (menu) {
			case 1:
				p.getContaPoupanca().mostrarSaldo();
				acessarContaPoupanca(p);
				break;
			case 2:
				ContaPoupanca teste = p.getContaPoupanca().transferir(pessoaDao.ListarTodos());
				//ContaPoupanca teste2 = contaPoupancaDao.pesquisar(teste.getNumeroConta());
				contaPoupancaDao.alterar(teste);
				Pessoa pessoa = p;
				pessoaDao.remover(p.getCpf());
				pessoaDao.salvar(pessoa);
				acessarContaPoupanca(pessoa);
				break;
			case 3:
				p.getContaPoupanca().resgatar(p.getContaCorrente());
				Pessoa pe = p;
				pessoaDao.remover(p.getCpf());
				pessoaDao.salvar(pe);
				acessarContaPoupanca(pe);
				break;
			case 4:
				menuCliente(p);
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida!!");
				menuCliente(p);
				break;
			}
		}
	}
}
