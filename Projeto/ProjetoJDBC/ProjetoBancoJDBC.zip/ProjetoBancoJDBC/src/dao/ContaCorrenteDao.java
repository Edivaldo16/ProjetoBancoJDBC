package dao;

import java.util.List;
import model.ContaCorrente;

public interface ContaCorrenteDao {
	
	public void salvar(ContaCorrente contaCorrente);
	public void alterar(ContaCorrente contaCorrente);
	public void remover(String numero);
	public ContaCorrente pesquisar(String numero);
	public List<ContaCorrente> ListarTodos();

}
