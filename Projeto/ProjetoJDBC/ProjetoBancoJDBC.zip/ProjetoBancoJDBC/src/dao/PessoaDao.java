package dao;

import java.util.ArrayList;
import java.util.List;

import model.Pessoa;

public interface PessoaDao {
	
	public void salvar(Pessoa pessoa);
	public void alterar(Pessoa pessoa);
	public void remover(String cpf);
	public Pessoa pesquisar(String cpf);
	public ArrayList<Pessoa> ListarTodos();

}
