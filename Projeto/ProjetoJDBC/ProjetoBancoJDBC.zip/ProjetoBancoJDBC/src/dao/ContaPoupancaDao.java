package dao;

import java.util.List;
import model.ContaPoupanca;

public interface ContaPoupancaDao {
	
	public void salvar(ContaPoupanca contaPoupanca);
	public void alterar(ContaPoupanca contaPoupanca);
	public void remover(String numero);
	public ContaPoupanca pesquisar(String numero);
	public List<ContaPoupanca> ListarTodos();

}
