package controller;

import javax.swing.JOptionPane;

import dao.ContaCorrenteDao;
import dao.ContaPoupancaDao;
import dao.EnderecoDao;
import dao.PessoaDao;
import impl.ContaCorrenteDaoImpl;
import impl.ContaPoupancaDaoImpl;
import impl.EnderecoDaoImpl;
import impl.PessoaDaoImpl;
import model.ContaCorrente;
import model.ContaPoupanca;
import model.Endereco;
import model.Pessoa;
import model.util.Conexao;

public class Teste {

	public static void main(String[] args) {

		Conexao conexao = new Conexao();

		// ContaCorrente
		// ContaCorrente 01
		ContaCorrente contaCorrente = new ContaCorrente();
		contaCorrente.setSaldo(45000d);
		
		/*
		System.out.println("Conta Corrente: " + contaCorrente.getNumeroConta());
		System.out.println("Senha: " + contaCorrente.getSenha());
		ContaCorrenteDao contaCorrenteDao = new ContaCorrenteDaoImpl(conexao);
		contaCorrenteDao.salvar(contaCorrente);
		contaCorrenteDao.alterar(contaCorrente);
		System.out.println("Conta Corrente: " + contaCorrente.getNumeroConta());
		System.out.println("Senha: " + contaCorrente.getSenha());
		System.out.println(contaCorrenteDao.pesquisar(contaCorrente.getNumeroConta()));
		*/

		// ContaCorrente 02
		ContaCorrente cc = new ContaCorrente();
		cc.setSaldo(55000d);
		
		/*
		ContaCorrenteDao ccDao = new ContaCorrenteDaoImpl(conexao);
		ccDao.salvar(cc);
		System.out.println(ccDao.ListarTodos());
		*/

		// ContaPoupanca
		// ContaPoupanca 01
		ContaPoupanca contaPoupanca = new ContaPoupanca(contaCorrente);
		contaPoupanca.setSaldo(10000d);
		
		/*
		System.out.println("Conta Corrente: " + contaPoupanca.getNumeroConta());
		System.out.println("Senha: " + contaPoupanca.getSenha());
		ContaPoupancaDao contaPoupancaDao = new ContaPoupancaDaoImpl(conexao);
		contaPoupancaDao.salvar(contaPoupanca);
		contaPoupancaDao.alterar(contaPoupanca);
		System.out.println("Conta Poupança: " + contaPoupanca.getNumeroConta());
		System.out.println("Senha: " + contaPoupanca.getSenha());
		System.out.println(contaPoupancaDao.pesquisar(contaPoupanca.getNumeroConta()));
		*/

		// ContaPoupanca 02
		ContaPoupanca cp = new ContaPoupanca(cc);
		cp.setSaldo(60000d);
		
		/*
		ContaPoupancaDao cpDao = new ContaPoupancaDaoImpl(conexao);
		cpDao.salvar(cp);
		System.out.println(cpDao.ListarTodos());
		*/

		// Endereço
		// Endereço 01
		Endereco endereco = new Endereco();
		endereco.setRua("Manoel Gois da Silva");
		endereco.setNumero(14);
		endereco.setComplemento("Próximo ao Marco Zero");

		/*
		EnderecoDao enderecoDao = new EnderecoDaoImpl(conexao);
		enderecoDao.salvar(endereco);
		*/

		// Endereço 02
		Endereco end = new Endereco();
		end.setRua("Alberto Firmino");
		end.setNumero(17);
		end.setComplemento("Próximo ao Armazém das Graças");

		/*
		EnderecoDao endDao = new EnderecoDaoImpl(conexao);
		endDao.salvar(end);
		*/
		
		// Pessoa 01
		Pessoa pessoa = new Pessoa();
		pessoa.setNome("Paulo Washinton");
		pessoa.setCpf("14725839669");
		pessoa.setSexo("Ma");
		pessoa.setIdade(45);
		pessoa.setEndereco(endereco);
		pessoa.setContaCorrente(contaCorrente);
		pessoa.setContaPoupanca(contaPoupanca);

		PessoaDao pessoaDao = new PessoaDaoImpl(conexao);
		pessoaDao.salvar(pessoa);
		//System.out.println(endereco.getNumero());
		//pessoaDao.pesquisar("14725839669");
		
		// Pessoa 02
		Pessoa pe = new Pessoa();
		pe.setNome("Francisca Koiakovisk");
		pe.setCpf("74185296336");
		pe.setSexo("Fe");
		pe.setIdade(45);
		pe.setEndereco(end);
		pe.setContaCorrente(cc);
		pe.setContaPoupanca(cp);

		PessoaDao peDao = new PessoaDaoImpl(conexao);
		peDao.salvar(pe);
		
		System.out.println(peDao.ListarTodos());
		System.out.println();
		//pessoaDao.remover("74185296336");
		//System.out.println(peDao.ListarTodos());

	}
}
