package model;

import model.util.Utils;

public abstract class Contas {
	// Atributos
	
	private int ID;
	private String numeroConta;
	private Double saldo;
	private String senha;
	
	// Métodos Personalizados Abstratos:
	public abstract void mostrarSaldo();
	public abstract void depositar();

	// Tratamento String ArrayList
	public String toString() {
		return "[numero=" + getNumeroConta() + ", saldo=" + saldo + ", senha=" + senha + "]";
	}

	// Métodos Especiais:
	// Getters and Setters

	public String getNumeroConta() {
		return this.numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
}
