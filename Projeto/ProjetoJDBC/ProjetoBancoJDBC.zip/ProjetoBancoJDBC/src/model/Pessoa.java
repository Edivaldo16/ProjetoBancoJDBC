package model;

public class Pessoa {
	private String nome;
	private String cpf;
	private String sexo;
	private String email;
	private Integer idade;
	private Endereco endereco;
	private ContaCorrente contaCorrente;
	private ContaPoupanca contaPoupanca;
	
	@Override
	public String toString() {
		return "Pessoa [Nome=" + nome + ", Cpf=" + cpf + ", Idade=" + idade + ", "
				+ "Endereço=" + endereco + ", ContaCorrente=" + contaCorrente + ", ContaPoupanca=" + contaPoupanca + "]";
	}

	public Pessoa(String nome, String cpf, String sexo, String email, Integer idade, Endereco endereco, ContaCorrente contaCorrente, ContaPoupanca contaPoupanca) {

		this.nome = nome;
		this.cpf = cpf;
		this.sexo = sexo;
		this.email = email;
		this.idade = idade;
		this.endereco = endereco;
		this.contaCorrente = contaCorrente;
		this.contaPoupanca = contaPoupanca;
	}

	public Pessoa() {
		super();
	}

	public String getNome() {
		return nome.replaceAll("[^a-zA-Z\\sáÁéÉíÍóÓúÚâÂêÊîÎôÔûÛãÃõÕçÇ]","").toUpperCase().trim();
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}
	
	public String modCpf() {
		StringBuilder strBuilder = new StringBuilder(this.getCpf());
		String a = strBuilder.insert(3, ".").toString();
		StringBuilder str = new StringBuilder(a);
		String b = str.insert(7, ".").toString();
		StringBuilder st = new StringBuilder(b);
		String c = st.insert(11, " - ").toString();

		return c;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getIdade() {
		return idade;
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public ContaCorrente getContaCorrente() {
		return contaCorrente;
	}

	public void setContaCorrente(ContaCorrente contaCorrente) {
		this.contaCorrente = contaCorrente;
	}

	public ContaPoupanca getContaPoupanca() {
		return contaPoupanca;
	}

	public void setContaPoupanca(ContaPoupanca contaPoupanca) {
		this.contaPoupanca = contaPoupanca;
	}

}
