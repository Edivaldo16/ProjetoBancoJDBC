package model;

public class Endereco {
	private Integer id;
	private String rua;
	private Integer numero;
	private String complemento;
	private String cidade;
	private String estado;
	
	@Override
	public String toString() {
		return "[Id_Endereço=" + id + ", Rua=" + rua + 
				", Número=" + numero + ", Complemento=" + complemento 
				+ ", Cidade=" + cidade + "Estado=" + estado + "]";
	}

	public Endereco(Integer id, String rua, Integer numero, String complemento, String cidade, String estado) {
		this.id = id;
		this.rua = rua;
		this.numero = numero;
		this.complemento = complemento;
		this.cidade = cidade;
		this.estado = estado;
	}

	public Endereco() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public String getRua() {
		return rua;
	}

	public Integer getNumero() {
		return numero;
	}

	public String getComplemento() {
		return complemento.replaceAll("[^a-zA-Z\\sáÁéÉíÍóÓúÚâÂêÊîÎôÔûÛãÃõÕçÇ]","").toUpperCase().trim();
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getCidade() {
		return cidade.replaceAll("[^a-zA-Z\\sáÁéÉíÍóÓúÚâÂêÊîÎôÔûÛãÃõÕçÇ]","").toUpperCase().trim();
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado.replaceAll("[^a-zA-Z\\sáÁéÉíÍóÓúÚâÂêÊîÎôÔûÛãÃõÕçÇ]","").toUpperCase().trim();
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
}
